<label class="mt-2" for="basicInput">{{getProperty($field_value,"name_fa")}}</label>
<div id="purchaseForm"></div>
<input name="purchase_form" value="{{$item_value}}" class="d-none">
