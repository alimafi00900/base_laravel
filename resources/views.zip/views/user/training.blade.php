@extends("user.layouts.mainLayout")
@section("title")
    اموزش ها
@endsection
@section("content")

    <main>
        <div class="container-lg container-fluid">
            <div class="row col-cheng">
                <div class="col-12 mt-5">
                    <div class="topic-shadow">
                        <h1>
                            آموزش های ایران نوا
                        </h1>
                        <span>
                        Training
                    </span>
                    </div>
                </div>

                <div class="col col-sm-6 col-md-4 col-lg-3 mt-4">
                    <div class="cart-boxLerning">
{{--                        <div class="cart-boxLerning-img">--}}
{{--                            <a href=""><img src="{{asset("/assets/image/img/NoPath - Copy (108).png")}}" alt=""></a>--}}
{{--                            <span>--}}
{{--                                <img src="{{asset("/assets/image/img/Group6796.png")}}" alt="">--}}
{{--                            </span>--}}
{{--                        </div>--}}
                        <div class="cart-boxLerning-content">
                            <a href="">
                                آموزش نحوه استفاده از گیفت کارت آموزش ساختن
                            </a>
                            <div class="cart-boxLerning-content-info">
                                <img src="{{asset("/assets/image/img/c1cb904db7c834fb45a0f30dcb17f204.png")}}" alt="">
                                <span>
                                    <dd>امیر حسین جلیلوند</dd>
                                    <dd>31 مرداد 1400 </dd>
                                </span>
                                <a href=""><img src="{{asset("/assets/image/img/Group-6424.svg")}}" alt=""></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col col-sm-6 col-md-4 col-lg-3 mt-4">
                    <div class="cart-boxLerning">
{{--                        <div class="cart-boxLerning-img">--}}
{{--                            <a href=""><img src="{{asset("/assets/image/img/NoPath - Copy (108).png")}}" alt=""></a>--}}
{{--                            <span>--}}
{{--                                <img src="{{asset("/assets/image/img/Group6796.png")}}" alt="">--}}
{{--                            </span>--}}
{{--                        </div>--}}
                        <div class="cart-boxLerning-content">
                            <a href="">
                                آموزش نحوه استفاده از گیفت کارت آموزش ساختن
                            </a>
                            <div class="cart-boxLerning-content-info">
                                <img src="{{asset("/assets/image/img/c1cb904db7c834fb45a0f30dcb17f204.png")}}" alt="">
                                <span>
                                    <dd>امیر حسین جلیلوند</dd>
                                    <dd>31 مرداد 1400 </dd>
                                </span>
                                <a href=""><img src="{{asset("/assets/image/img/Group-6424.svg")}}" alt=""></a>
                            </div>
                        </div>
                    </div>
                </div>  <div class="col col-sm-6 col-md-4 col-lg-3 mt-4">
                    <div class="cart-boxLerning">
{{--                        <div class="cart-boxLerning-img">--}}
{{--                            <a href=""><img src="{{asset("/assets/image/img/NoPath - Copy (108).png")}}" alt=""></a>--}}
{{--                            <span>--}}
{{--                                <img src="{{asset("/assets/image/img/Group6796.png")}}" alt="">--}}
{{--                            </span>--}}
{{--                        </div>--}}
                        <div class="cart-boxLerning-content">
                            <a href="">
                                آموزش نحوه استفاده از گیفت کارت آموزش ساختن
                            </a>
                            <div class="cart-boxLerning-content-info">
                                <img src="{{asset("/assets/image/img/c1cb904db7c834fb45a0f30dcb17f204.png")}}" alt="">
                                <span>
                                    <dd>امیر حسین جلیلوند</dd>
                                    <dd>31 مرداد 1400 </dd>
                                </span>
                                <a href=""><img src="{{asset("/assets/image/img/Group-6424.svg")}}" alt=""></a>
                            </div>
                        </div>
                    </div>
                </div>  <div class="col col-sm-6 col-md-4 col-lg-3 mt-4">
                    <div class="cart-boxLerning">
{{--                        <div class="cart-boxLerning-img">--}}
{{--                            <a href=""><img src="{{asset("/assets/image/img/NoPath - Copy (108).png")}}" alt=""></a>--}}
{{--                            <span>--}}
{{--                                <img src="{{asset("/assets/image/img/Group6796.png")}}" alt="">--}}
{{--                            </span>--}}
{{--                        </div>--}}
                        <div class="cart-boxLerning-content">
                            <a href="">
                                آموزش نحوه استفاده از گیفت کارت آموزش ساختن
                            </a>
                            <div class="cart-boxLerning-content-info">
                                <img src="{{asset("/assets/image/img/c1cb904db7c834fb45a0f30dcb17f204.png")}}" alt="">
                                <span>
                                    <dd>امیر حسین جلیلوند</dd>
                                    <dd>31 مرداد 1400 </dd>
                                </span>
                                <a href=""><img src="{{asset("/assets/image/img/Group-6424.svg")}}" alt=""></a>
                            </div>
                        </div>
                    </div>
                </div>  <div class="col col-sm-6 col-md-4 col-lg-3 mt-4">
                    <div class="cart-boxLerning">
{{--                        <div class="cart-boxLerning-img">--}}
{{--                            <a href=""><img src="{{asset("/assets/image/img/NoPath - Copy (108).png")}}" alt=""></a>--}}
{{--                            <span>--}}
{{--                                <img src="{{asset("/assets/image/img/Group6796.png")}}" alt="">--}}
{{--                            </span>--}}
{{--                        </div>--}}
                        <div class="cart-boxLerning-content">
                            <a href="">
                                آموزش نحوه استفاده از گیفت کارت آموزش ساختن
                            </a>
                            <div class="cart-boxLerning-content-info">
                                <img src="{{asset("/assets/image/img/c1cb904db7c834fb45a0f30dcb17f204.png")}}" alt="">
                                <span>
                                    <dd>امیر حسین جلیلوند</dd>
                                    <dd>31 مرداد 1400 </dd>
                                </span>
                                <a href=""><img src="{{asset("/assets/image/img/Group-6424.svg")}}" alt=""></a>
                            </div>
                        </div>
                    </div>
                </div>  <div class="col col-sm-6 col-md-4 col-lg-3 mt-4">
                    <div class="cart-boxLerning">
{{--                        <div class="cart-boxLerning-img">--}}
{{--                            <a href=""><img src="{{asset("/assets/image/img/NoPath - Copy (108).png")}}" alt=""></a>--}}
{{--                            <span>--}}
{{--                                <img src="{{asset("/assets/image/img/Group6796.png")}}" alt="">--}}
{{--                            </span>--}}
{{--                        </div>--}}
                        <div class="cart-boxLerning-content">
                            <a href="">
                                آموزش نحوه استفاده از گیفت کارت آموزش ساختن
                            </a>
                            <div class="cart-boxLerning-content-info">
                                <img src="{{asset("/assets/image/img/c1cb904db7c834fb45a0f30dcb17f204.png")}}" alt="">
                                <span>
                                    <dd>امیر حسین جلیلوند</dd>
                                    <dd>31 مرداد 1400 </dd>
                                </span>
                                <a href=""><img src="{{asset("/assets/image/img/Group-6424.svg")}}" alt=""></a>
                            </div>
                        </div>
                    </div>
                </div>  <div class="col col-sm-6 col-md-4 col-lg-3 mt-4">
                    <div class="cart-boxLerning">
{{--                        <div class="cart-boxLerning-img">--}}
{{--                            <a href=""><img src="{{asset("/assets/image/img/NoPath - Copy (108).png")}}" alt=""></a>--}}
{{--                            <span>--}}
{{--                                <img src="{{asset("/assets/image/img/Group6796.png")}}" alt="">--}}
{{--                            </span>--}}
{{--                        </div>--}}
                        <div class="cart-boxLerning-content">
                            <a href="">
                                آموزش نحوه استفاده از گیفت کارت آموزش ساختن
                            </a>
                            <div class="cart-boxLerning-content-info">
                                <img src="{{asset("/assets/image/img/c1cb904db7c834fb45a0f30dcb17f204.png")}}" alt="">
                                <span>
                                    <dd>امیر حسین جلیلوند</dd>
                                    <dd>31 مرداد 1400 </dd>
                                </span>
                                <a href=""><img src="{{asset("/assets/image/img/Group-6424.svg")}}" alt=""></a>
                            </div>
                        </div>
                    </div>
                </div>  <div class="col col-sm-6 col-md-4 col-lg-3 mt-4">
                    <div class="cart-boxLerning">
{{--                        <div class="cart-boxLerning-img">--}}
{{--                            <a href=""><img src="{{asset("/assets/image/img/NoPath - Copy (108).png")}}" alt=""></a>--}}
{{--                            <span>--}}
{{--                                <img src="{{asset("/assets/image/img/Group6796.png")}}" alt="">--}}
{{--                            </span>--}}
{{--                        </div>--}}
                        <div class="cart-boxLerning-content">
                            <a href="">
                                آموزش نحوه استفاده از گیفت کارت آموزش ساختن
                            </a>
                            <div class="cart-boxLerning-content-info">
                                <img src="{{asset("/assets/image/img/c1cb904db7c834fb45a0f30dcb17f204.png")}}" alt="">
                                <span>
                                    <dd>امیر حسین جلیلوند</dd>
                                    <dd>31 مرداد 1400 </dd>
                                </span>
                                <a href=""><img src="{{asset("/assets/image/img/Group-6424.svg")}}" alt=""></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12 mt-5">
                    <div class="pagination-SixSide">
                        <ul>
                            <li><a href="#"><svg xmlns="http://www.w3.org/2000/svg"  viewBox="0 0 17.506 30.903">
                                        <path id="Stroke_3" data-name="Stroke 3" d="M0,0,12.623,12.678,25.246,0" transform="translate(14.678 2.828) rotate(90)" fill="none" stroke="" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" stroke-width="4"/>
                                    </svg>
                                </a></li>
                            <li><a href="#">1</a></li>
                            <li><a href="#">2</a></li>
                            <li><a href="#">...</a></li>
                            <li><a href="#">5</a></li>
                            <li><a href="#"><svg xmlns="http://www.w3.org/2000/svg"  viewBox="0 0 17.506 30.903">
                                        <path id="Stroke_3" data-name="Stroke 3" d="M0,0,12.623,12.678,25.246,0" transform="translate(14.678 2.828) rotate(90)" fill="none" stroke="" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" stroke-width="4"/>
                                    </svg>
                                </a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </main>

@endsection