<div class="d-flex mr-4">
    <button class="btn btn-sm btn-info" id="select-multiple-item">انخاب چند مورد</button>
    <button style="display: none" id="delete-multiple-item" class="btn mr-1 btn-sm btn-danger">حذف</button>
    <button style="display: none" id="cancel-multiple-item" class="btn btn-sm btn-primary">لغو</button>
</div>
