<footer class="footer">
    <div class="container-fluid">
        <nav class="float-left">
            <ul>
                <li>
                    <a href="">

                    </a>
                </li>
            </ul>
        </nav>
        <div class="copyright float-right">
{{--            &copy;--}}
            <script>
                // document.write(new Date().getFullYear())
            </script>

        </div>
    </div>
</footer>
