@extends("admin.layouts.basic_layouts.admin_items_edit")
@php
    $templateName_route_name="admin.branches";
    $templateName_single_fa="شاخه";
    $templateName_sum_fa="شاخه ها";
@endphp
@section("form_edit")
    <div class="row d-block">
        <div class="col-md-4">
            <label for="" class="mt-4">نام نمایشی </label>
            <input type="text" class="form-control" id="name-input-from" name="display_name"
                   value="{{$item->display_name}}"  required>
            <br>
        </div>


        <div class="col-md-4">
            <label for="" class="mt-4">نام</label>
            <input type="text" class="form-control" id="name-input-from" name="name"
                   value="{{$item->name}}"  required>
            <br>
        </div>




    </div>
@endsection
